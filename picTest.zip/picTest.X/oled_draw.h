/* 
 * File:   oled_draw.h
 * Author: jesus
 *
 * Created on January 31, 2014, 7:29 PM
 */

#ifndef OLED_DRAW_H
#define	OLED_DRAW_H

#include <stdint.h>

void oled_putPixel(uint8_t* buffer, uint8_t x, uint8_t y);

#endif	/* OLED_DRAW_H */

