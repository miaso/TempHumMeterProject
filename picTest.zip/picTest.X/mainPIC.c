/*
 * File:   mainPIC.c
 * Author: IdeaPad
 *
 * Created on 24. februar 2016, 11:05
 */


#include "xc.h"
#include "oled.h"
#include <stdint.h>
#include "hwConfig.h"
#include "uart1.h"
#include "extralDefines.h"
#include "rtcc.h"
#include <stdlib.h>

#include "i2c1.h"


#define FCY     16000000ULL //TO DO

#include <libpic30.h>
#include "dht.h"
#include "si7020.h"

 volatile char ttLSB,ttMSB,hhLSB,hhMSB;
volatile uint16_v temperatureCode;
volatile uint16_v humidityCode;
volatile int temperatureValue;
volatile int humidityValue;

/// CONFIGURRATION BITS 
_CONFIG1(JTAGEN_OFF & GCP_OFF & GWRP_OFF & LPCFG_ON & ICS_PGx3 & WINDIS_OFF & FWDTEN_WDT_DIS & FWPSA_PR32 & WDTPS_PS1)
_CONFIG2(IESO_OFF & ALTVREF_ALT_AV_ALT_CV & FNOSC_FRCPLL & FCKSM_CSDCMD & OSCIOFCN_ON & IOL1WAY_OFF & POSCMD_NONE)
_CONFIG3(WPEND_WPENDMEM & WPCFG_WPCFGEN & WPDIS_WPEN & BOREN_OFF & WDTWIN_PS50_0 & SOSCSEL_ON & VBTBOR_OFF & WPFP_WPFP82)
_CONFIG4(DSSWEN_OFF & DSWDTEN_OFF & DSBOREN_OFF & DSWDTOSC_SOSC & DSWDTPS_DSWDTPS0)



struct tm currentTime;

//Repeater main function

void RepeaterProcessEvents() {
    unsigned char data = 0;

    //wait for data to be received
    data = UART1GetChar();

    //send data back on UART TX line
    UART1PutChar(data);
}

void tester(){
    i2c_start();  
    send_i2c_byte(0x80);// address +0 write
    
    send_i2c_byte(0xE3);  //0xE3 =0b11100011
    
   i2c_repeatedStart();
   //i2c_start(); 
   
   send_i2c_byte(0x81); //adresss +1 read
   i2c_mIdleI2C1();
    
   ttLSB=i2c_read_ack();
   i2c_ack();
   
  i2c_mIdleI2C1();
   i2c_ack();
   ttMSB=i2c_read_ack();
   i2c_mIdleI2C1();     /////////////////////// maybe?
   i2c_nack();
   i2c_stop();

   temperatureCode.b[0]=ttLSB;
   temperatureCode.b[1]=ttMSB;

}

void humidityTester(){
    i2c_start();  
    send_i2c_byte(0x80);// address +0 write
    
    send_i2c_byte(0xE5);  //0xE5 =0b11100101 
   i2c_repeatedStart(); 
   send_i2c_byte(0x81); //adresss +1 read
   i2c_mIdleI2C1();
   hhLSB=i2c_read_ack();
   i2c_ack();
   i2c_mIdleI2C1();
   i2c_ack();
   hhMSB=i2c_read_ack();
   i2c_mIdleI2C1();     /////////////////////// maybe?
   i2c_nack();
   i2c_stop();

   humidityCode.b[0]=hhLSB;
   humidityCode.b[1]=hhMSB;
}

void firmwareTest(){
     i2c_start();  
    send_i2c_byte(0x80);// address +0 write
    
     send_i2c_byte(0x84);    /// FIRMWARE!!!!!!!!!
    
    send_i2c_byte(0xB8); /// FIRMWARE!!!!!!!!!
//0x84 =0b10000100
//0xB8 =0b10111000
    i2c_start(); /// FIRMWARE!!!!!!!!!
   send_i2c_byte(0x81); /// FIRMWARE!!!!!!!!!
   
 //  cc3=i2c_read();
   
  // i2c_stop();
}

//RTCTime time; // declare the type of the time object

int main(void) {


    OSCCON = 0x1102; // clock setup   0001 0001 0000 0010
    CLKDIV = 0x0000;
    OSCTUN = 0x0000;
    RCON |= 0x1100;


    /// Hardware setup
    hwInit();
    RTCC_Initialize();
    I2C1_Initialize();
    INITIALIZE_SI7020();


    //    MICI: MI2C1 - I2C1 Master Events
    //    Priority: 1
    IPC4bits.MI2C1P = 1;
    //    SICI: SI2C1 - I2C1 Slave Events
    //    Priority: 1
    IPC4bits.SI2C1P = 1;

    // Display setup and test
    oled_init();
    oled_clearDisplay();
    oled_prints(1, 6, "Temp:"); // print on center of the screen
    oled_prints(1, 8, "Humidity:");
    oled_render();



    __delay_ms(1000);

    UART1Init(51);

    UART1PutChar('b');

    UART1PutStr("Init complete");


    while (1) {
    


        
        
        //  RTCC_TimeGet(&currentTime);
        UART1PutChar('/');

    tester();
    temperatureValue=calculateTemperature(temperatureCode);     
    humidityTester();
    humidityValue=calculateHumidity(humidityCode);

    UART1PutChar('*');
   // UART1PutStr(buf);
    
  //UART1PutChar(l & 0xff);
  //UART1PutChar(l >> 8);
    
  UART1PutChar('*');
  
         UART1PutChar(ttLSB);
         UART1PutChar(ttMSB);  
  UART1PutChar('*');
        __delay_ms(200);
        
    char str[10];
    char humm[10];

    sprintf(str, "%d", temperatureValue);
   oled_prints(30, 6,str);
    
    sprintf(humm, "%d", humidityValue);
    oled_prints(45, 8 ,humm);
    oled_render();
     UART1PutStr(str);
    }
    return (0);
}

// 15 NA 14-12 Fast RC Oscillator (FRC) 000 // 11 NA 10-8 000 Fast RC Oscillator (FRC) // bit7 0 CLLOCK // Bit 6 NA // bit 5=0 LOCK //bit 4 NA// bit 3 CLOCK fail // bit2 NA // bit 1 Secondary osc  0 // bit 0 OSWEN 
//Loop forever



