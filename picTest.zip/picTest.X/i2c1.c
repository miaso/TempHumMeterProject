/**
  I2C1 Generated Driver File

  @Company
    Microchip Technology Inc.

  @File Name
    i2c1.c

  @Summary
    This is the generated header file for the I2C1 driver using MPLAB(c) Code Configurator

  @Description
    This header file provides APIs for driver for I2C1.
    Generation Information :
        Product Revision  :  MPLAB(c) Code Configurator - v3.00
        Device            :  PIC24FJ128GA306
        Driver Version    :  1.0
    The generated drivers are tested against the following:
        Compiler          :  XC16 1.26
        MPLAB 	          :  MPLAB X 3.20
 */

/*
Copyright (c) 2013 - 2015 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 */

#include "i2c1.h"
#include "si7020.h"
#include "uart1.h"
#include "extralDefines.h"
#define FCY     16000000ULL //TO DO

#include <libpic30.h>
/**
 Section: Data Types
 */

/**
  I2C Driver Queue Status Type

  @Summary
    Defines the type used for the transaction queue status.

  @Description
    This defines type used to keep track of the queue status.
 */
volatile uint16_t tempo;
typedef union {

    struct {
        uint8_t full : 1;
        uint8_t empty : 1;
        uint8_t reserved : 6;
    } s;
    uint8_t status;
} I2C_TR_QUEUE_STATUS;

/**
  I2C Driver Queue Entry Type

  @Summary
    Defines the object used for an entry in the i2c queue items.

  @Description
    This defines the object in the i2c queue. Each entry is a composed
    of a list of TRBs, the number of the TRBs and the status of the
    currently processed TRB.
 */
typedef struct {
    uint8_t count; // a count of trb's in the trb list
    I2C1_TRANSACTION_REQUEST_BLOCK *ptrb_list; // pointer to the trb list
    I2C1_MESSAGE_STATUS *pTrFlag; // set with the error of the last trb sent.
    // if all trb's are sent successfully,
    // then this is I2C1_MESSAGE_COMPLETE
} I2C_TR_QUEUE_ENTRY;

/**
  I2C Master Driver Object Type

  @Summary
    Defines the object that manages the i2c master.

  @Description
    This defines the object that manages the sending and receiving of
    i2c master transactions.
 */

typedef struct {
    /* Read/Write Queue */
    I2C_TR_QUEUE_ENTRY *pTrTail; // tail of the queue
    I2C_TR_QUEUE_ENTRY *pTrHead; // head of the queue
    I2C_TR_QUEUE_STATUS trStatus; // status of the last transaction
    uint8_t i2cDoneFlag; // flag to indicate the current
    // transaction is done
    uint8_t i2cErrors; // keeps track of errors


} I2C_OBJECT;

/**
  I2C Master Driver State Enumeration

  @Summary
    Defines the different states of the i2c master.

  @Description
    This defines the different states that the i2c master
    used to process transactions on the i2c bus.
 */

typedef enum {
    S_MASTER_IDLE,
    S_MASTER_RESTART,
    S_MASTER_SEND_ADDR,
    S_MASTER_SEND_DATA,
    S_MASTER_SEND_STOP,
    S_MASTER_ACK_ADDR,
    S_MASTER_RCV_DATA,
    S_MASTER_RCV_STOP,
    S_MASTER_ACK_RCV_DATA,
    S_MASTER_NOACK_STOP,
    S_MASTER_SEND_ADDR_10BIT_LSB,
    S_MASTER_10BIT_RESTART,

} I2C_MASTER_STATES;

/**
 Section: Macro Definitions
 */

/* defined for I2C1 */


#ifndef I2C1_CONFIG_TR_QUEUE_LENGTH
#define I2C1_CONFIG_TR_QUEUE_LENGTH 1
#endif

#define I2C1_TRANSMIT_REG                       I2C1TRN                 // Defines the transmit register used to send data.
#define I2C1_RECEIVE_REG                        I2C1RCV                 // Defines the receive register used to receive data.

// The following control bits are used in the I2C state machine to manage
// the I2C module and determine next states.
#define I2C1_WRITE_COLLISION_STATUS_BIT         I2C1STATbits.IWCOL      // Defines the write collision status bit.
#define I2C1_ACKNOWLEDGE_STATUS_BIT             I2C1STATbits.ACKSTAT    // I2C ACK status bit.

#define I2C1_START_CONDITION_ENABLE_BIT         I2C1CONbits.SEN         // I2C START control bit.
#define I2C1_REPEAT_START_CONDITION_ENABLE_BIT  I2C1CONbits.RSEN        // I2C Repeated START control bit.
#define I2C1_RECEIVE_ENABLE_BIT                 I2C1CONbits.RCEN        // I2C Receive enable control bit.
#define I2C1_STOP_CONDITION_ENABLE_BIT          I2C1CONbits.PEN         // I2C STOP control bit.
#define I2C1_ACKNOWLEDGE_ENABLE_BIT             I2C1CONbits.ACKEN       // I2C ACK start control bit.
#define I2C1_ACKNOWLEDGE_DATA_BIT               I2C1CONbits.ACKDT       // I2C ACK data control bit.

/**
 Section: Local Functions
 */

static void I2C1_FunctionComplete(void);
static void I2C1_Stop(I2C1_MESSAGE_STATUS completion_code);

/**
 Section: Local Variables
 */

static I2C_TR_QUEUE_ENTRY i2c1_tr_queue[I2C1_CONFIG_TR_QUEUE_LENGTH];
static I2C_OBJECT i2c1_object;
static I2C_MASTER_STATES i2c1_state = S_MASTER_IDLE;
static uint8_t i2c1_trb_count;

static I2C1_TRANSACTION_REQUEST_BLOCK *p_i2c1_trb_current;
static I2C_TR_QUEUE_ENTRY *p_i2c1_current = NULL;

/**
  Section: Driver Interface
 */

void I2C1_Initialize(void) {

    i2c1_object.pTrHead = i2c1_tr_queue;
    i2c1_object.pTrTail = i2c1_tr_queue;
    i2c1_object.trStatus.s.empty = true;
    i2c1_object.trStatus.s.full = false;

    i2c1_object.i2cErrors = 0;

    // initialize the hardware
    // Baud Rate Generator Value: I2CBRG 2;   
    // Calculated Frequency: 100/404.0 kHz
    I2C1BRG = 0x9D;//9D;  -100 //0x25;-404
    // ACKEN disabled; STREN disabled; GCEN disabled; SMEN disabled; DISSLW disabled; I2CSIDL disabled; ACKDT Sends ACK; SCLREL Holds; RSEN disabled; IPMIEN disabled; A10M 7 Bit; PEN disabled; RCEN disabled; SEN disabled; I2CEN enabled; 
    I2C1CON = 0x8200;
    // P disabled; S disabled; BCL disabled; I2COV disabled; IWCOL disabled; 
    I2C1STAT = 0x0000;

    /* MI2C1 - I2C1 Master Events */
    // clear the master interrupt flag
    IFS1bits.MI2C1IF = 0;
    // enable the master interrupt
    IEC1bits.MI2C1IE = 1;

}

void DRV_I2C1_Initialize(void) {
    I2C1_Initialize();
}

uint8_t I2C1_ErrorCountGet(void) {
    uint8_t ret;

    ret = i2c1_object.i2cErrors;
    return ret;
}

void __attribute__((interrupt, no_auto_psv)) _MI2C1Interrupt(void) {



    static uint8_t *pi2c_buf_ptr;
    static uint16_t i2c_address;
    static uint8_t i2c_bytes_left;
    static uint8_t i2c_10bit_address_restart = 0;



    IFS1bits.MI2C1IF = 0;

    // Check first if there was a collision.
    // If we have a Write Collision, reset and go to idle state */
    if (I2C1_WRITE_COLLISION_STATUS_BIT) {
        // clear the Write colision
        I2C1_WRITE_COLLISION_STATUS_BIT = 0;
        i2c1_state = S_MASTER_IDLE;
        *(p_i2c1_current->pTrFlag) = I2C1_MESSAGE_FAIL;

        // reset the buffer pointer
        p_i2c1_current = NULL;

        return;
    }

    /* Handle the correct i2c state */
    switch (i2c1_state) {
        case S_MASTER_IDLE: /* In reset state, waiting for data to send */

            if (i2c1_object.trStatus.s.empty != true) {
                // grab the item pointed by the head
                p_i2c1_current = i2c1_object.pTrHead;
                i2c1_trb_count = i2c1_object.pTrHead->count;
                p_i2c1_trb_current = i2c1_object.pTrHead->ptrb_list;

                i2c1_object.pTrHead++;

                // check if the end of the array is reached
                if (i2c1_object.pTrHead == (i2c1_tr_queue + I2C1_CONFIG_TR_QUEUE_LENGTH)) {
                    // adjust to restart at the beginning of the array
                    i2c1_object.pTrHead = i2c1_tr_queue;
                }

                // since we moved one item to be processed, we know
                // it is not full, so set the full status to false
                i2c1_object.trStatus.s.full = false;

                // check if the queue is empty
                if (i2c1_object.pTrHead == i2c1_object.pTrTail) {
                    // it is empty so set the empty status to true
                    i2c1_object.trStatus.s.empty = true;
                }

                // send the start condition
                I2C1_START_CONDITION_ENABLE_BIT = 1;

                // start the i2c request
                i2c1_state = S_MASTER_SEND_ADDR;
            }

            break;

        case S_MASTER_RESTART:

            /* check for pending i2c Request */

            // ... trigger a REPEATED START
            I2C1_REPEAT_START_CONDITION_ENABLE_BIT = 1;

            // start the i2c request
            i2c1_state = S_MASTER_SEND_ADDR;

            break;

        case S_MASTER_SEND_ADDR_10BIT_LSB:

            if (I2C1_ACKNOWLEDGE_STATUS_BIT) {
                i2c1_object.i2cErrors++;
                I2C1_Stop(I2C1_MESSAGE_ADDRESS_NO_ACK);
            } else {
                // Remove bit 0 as R/W is never sent here
                I2C1_TRANSMIT_REG = (i2c_address >> 1) & 0x00FF;

                // determine the next state, check R/W
                if (i2c_address & 0x01) {
                    // if this is a read we must repeat start
                    // the bus to perform a read
                    i2c1_state = S_MASTER_10BIT_RESTART;
                } else {
                    // this is a write continue writing data
                    i2c1_state = S_MASTER_SEND_DATA;
                }
            }

            break;

        case S_MASTER_10BIT_RESTART:

            if (I2C1_ACKNOWLEDGE_STATUS_BIT) {
                i2c1_object.i2cErrors++;
                I2C1_Stop(I2C1_MESSAGE_ADDRESS_NO_ACK);
            } else {
                // ACK Status is good
                // restart the bus
                I2C1_REPEAT_START_CONDITION_ENABLE_BIT = 1;

                // fudge the address so S_MASTER_SEND_ADDR works correctly
                // we only do this on a 10-bit address resend
                i2c_address = 0x00F0 | ((i2c_address >> 8) & 0x0006);

                // set the R/W flag
                i2c_address |= 0x0001;

                // set the address restart flag so we do not change the address
                i2c_10bit_address_restart = 1;

                // Resend the address as a read
                i2c1_state = S_MASTER_SEND_ADDR;
            }

            break;

        case S_MASTER_SEND_ADDR:

            /* Start has been sent, send the address byte */

            /* Note: 
                On a 10-bit address resend (done only during a 10-bit
                device read), the original i2c_address was modified in
                S_MASTER_10BIT_RESTART state. So the check if this is
                a 10-bit address will fail and a normal 7-bit address
                is sent with the R/W bit set to read. The flag
                i2c_10bit_address_restart prevents the  address to
                be re-written.
             */
            if (i2c_10bit_address_restart != 1) {
                // extract the information for this message
                i2c_address = p_i2c1_trb_current->address;
                pi2c_buf_ptr = p_i2c1_trb_current->pbuffer;
                i2c_bytes_left = p_i2c1_trb_current->length;
            } else {
                // reset the flag so the next access is ok
                i2c_10bit_address_restart = 0;
            }

            // check for 10-bit address
            if (i2c_address > 0x00FF) {
                // we have a 10 bit address
                // send bits<9:8>
                // mask bit 0 as this is always a write
                I2C1_TRANSMIT_REG = 0xF0 | ((i2c_address >> 8) & 0x0006);
                i2c1_state = S_MASTER_SEND_ADDR_10BIT_LSB;
            } else {
                // Transmit the address
                I2C1_TRANSMIT_REG = i2c_address;
                if (i2c_address & 0x01) {
                    // Next state is to wait for address to be acked
                    i2c1_state = S_MASTER_ACK_ADDR;
                } else {
                    // Next state is transmit
                    i2c1_state = S_MASTER_SEND_DATA;
                }
            }
            break;

        case S_MASTER_SEND_DATA:

            // Make sure the previous byte was acknowledged
            if (I2C1_ACKNOWLEDGE_STATUS_BIT) {
                // Transmission was not acknowledged
                i2c1_object.i2cErrors++;

                // Reset the Ack flag
                I2C1_ACKNOWLEDGE_STATUS_BIT = 0;

                // Send a stop flag and go back to idle
                I2C1_Stop(I2C1_DATA_NO_ACK);

            } else {
                // Did we send them all ?
                if (i2c_bytes_left-- == 0U) {
                    // yup sent them all!

                    // update the trb pointer
                    p_i2c1_trb_current++;

                    // are we done with this string of requests?
                    if (--i2c1_trb_count == 0) {
                        I2C1_Stop(I2C1_MESSAGE_COMPLETE);
                    } else {
                        // no!, there are more TRB to be sent.
                        //I2C1_START_CONDITION_ENABLE_BIT = 1;

                        // In some cases, the slave may require
                        // a restart instead of a start. So use this one
                        // instead.
                        I2C1_REPEAT_START_CONDITION_ENABLE_BIT = 1;

                        // start the i2c request
                        i2c1_state = S_MASTER_SEND_ADDR;

                    }
                } else {
                    // Grab the next data to transmit
                    I2C1_TRANSMIT_REG = *pi2c_buf_ptr++;
                }
            }
            break;

        case S_MASTER_ACK_ADDR:

            /* Make sure the previous byte was acknowledged */
            if (I2C1_ACKNOWLEDGE_STATUS_BIT) {

                // Transmission was not acknowledged
                i2c1_object.i2cErrors++;

                // Send a stop flag and go back to idle
                I2C1_Stop(I2C1_MESSAGE_ADDRESS_NO_ACK);

                // Reset the Ack flag
                I2C1_ACKNOWLEDGE_STATUS_BIT = 0;
            } else {
                I2C1_RECEIVE_ENABLE_BIT = 1;
                i2c1_state = S_MASTER_ACK_RCV_DATA;
            }
            break;

        case S_MASTER_RCV_DATA:

            /* Acknowledge is completed.  Time for more data */

            // Next thing is to ack the data
            i2c1_state = S_MASTER_ACK_RCV_DATA;

            // Set up to receive a byte of data
            I2C1_RECEIVE_ENABLE_BIT = 1;

            break;

        case S_MASTER_ACK_RCV_DATA:

            // Grab the byte of data received and acknowledge it
            *pi2c_buf_ptr++ = I2C1_RECEIVE_REG;

            // Check if we received them all?
            if (--i2c_bytes_left) {

                /* No, there's more to receive */

                // No, bit 7 is clear.  Data is ok
                // Set the flag to acknowledge the data
                I2C1_ACKNOWLEDGE_DATA_BIT = 0;

                // Wait for the acknowledge to complete, then get more
                i2c1_state = S_MASTER_RCV_DATA;
            } else {

                // Yes, it's the last byte.  Don't ack it
                // Flag that we will nak the data
                I2C1_ACKNOWLEDGE_DATA_BIT = 1;

                I2C1_FunctionComplete();
            }

            // Initiate the acknowledge
            I2C1_ACKNOWLEDGE_ENABLE_BIT = 1;
            break;

        case S_MASTER_RCV_STOP:
        case S_MASTER_SEND_STOP:

            // Send the stop flag
            I2C1_Stop(I2C1_MESSAGE_COMPLETE);
            break;

        default:

            // This case should not happen, if it does then
            // terminate the transfer
            i2c1_object.i2cErrors++;
            I2C1_Stop(I2C1_LOST_STATE);
            break;

    }
}

static void I2C1_FunctionComplete(void) {

    // update the trb pointer
    p_i2c1_trb_current++;

    // are we done with this string of requests?
    if (--i2c1_trb_count == 0) {
        i2c1_state = S_MASTER_SEND_STOP;
    } else {
        i2c1_state = S_MASTER_RESTART;
    }

}

static void I2C1_Stop(I2C1_MESSAGE_STATUS completion_code) {
    // then send a stop
    I2C1_STOP_CONDITION_ENABLE_BIT = 1;

    // make sure the flag pointer is not NULL
    if (p_i2c1_current->pTrFlag != NULL) {
        // update the flag with the completion code
        *(p_i2c1_current->pTrFlag) = completion_code;
    }

    // Done, back to idle
    i2c1_state = S_MASTER_IDLE;

}

void I2C1_MasterWrite(
        uint8_t *pdata,
        uint8_t length,
        uint16_t address,
        I2C1_MESSAGE_STATUS *pstatus) {
    static I2C1_TRANSACTION_REQUEST_BLOCK trBlock;

    // check if there is space in the queue
    if (i2c1_object.trStatus.s.full != true) {
        I2C1_MasterWriteTRBBuild(&trBlock, pdata, length, address);
        I2C1_MasterTRBInsert(1, &trBlock, pstatus);
    } else {
        *pstatus = I2C1_MESSAGE_FAIL;
    }

}

void I2C1_si7020request(uint8_t *command, uint8_t length, uint16_t adress, I2C1_MESSAGE_STATUS *pstatus) {
    static I2C1_TRANSACTION_REQUEST_BLOCK trBlock;

    // check if there is space in the queue
    if (i2c1_object.trStatus.s.full != true) {
        I2C1_MasterWriteTRBBuild(&trBlock, command, length, adress);
        I2C1_MasterTRBInsert(1, &trBlock, pstatus);
    } else {
        *pstatus = I2C1_MESSAGE_FAIL;
    }



}

void I2C1_si7020Start() {

}

void DRV_I2C1_MasterWrite(
        uint8_t *pdata,
        uint8_t length,
        uint16_t address,
        DRV_I2C1_MESSAGE_STATUS *pstatus) {
    I2C1_MasterWrite(pdata, length, address, (I2C1_MESSAGE_STATUS *) pstatus);
}

void I2C1_MasterRead(
        uint8_t *pdata,
        uint8_t length,
        uint16_t address,
        I2C1_MESSAGE_STATUS *pstatus) {
    static I2C1_TRANSACTION_REQUEST_BLOCK trBlock;


    // check if there is space in the queue
    if (i2c1_object.trStatus.s.full != true) {
        I2C1_MasterReadTRBBuild(&trBlock, pdata, length, address);
        I2C1_MasterTRBInsert(1, &trBlock, pstatus);
    } else {
        *pstatus = I2C1_MESSAGE_FAIL;
    }

}

void DRV_I2C1_MasterRead(
        uint8_t *pdata,
        uint8_t length,
        uint16_t address,
        DRV_I2C1_MESSAGE_STATUS *pstatus) {
    I2C1_MasterRead(pdata, length, address, (I2C1_MESSAGE_STATUS *) pstatus);
}

void I2C1_MasterTRBInsert(
        uint8_t count,
        I2C1_TRANSACTION_REQUEST_BLOCK *ptrb_list,
        I2C1_MESSAGE_STATUS *pflag) {

    // check if there is space in the queue
    if (i2c1_object.trStatus.s.full != true) {
        *pflag = I2C1_MESSAGE_PENDING;

        i2c1_object.pTrTail->ptrb_list = ptrb_list;
        i2c1_object.pTrTail->count = count;
        i2c1_object.pTrTail->pTrFlag = pflag;
        i2c1_object.pTrTail++;

        // check if the end of the array is reached
        if (i2c1_object.pTrTail == (i2c1_tr_queue + I2C1_CONFIG_TR_QUEUE_LENGTH)) {
            // adjust to restart at the beginning of the array
            i2c1_object.pTrTail = i2c1_tr_queue;
        }

        // since we added one item to be processed, we know
        // it is not empty, so set the empty status to false
        i2c1_object.trStatus.s.empty = false;

        // check if full
        if (i2c1_object.pTrHead == i2c1_object.pTrTail) {
            // it is full, set the full status to true
            i2c1_object.trStatus.s.full = true;
        }

        // for interrupt based
        if (i2c1_state == S_MASTER_IDLE) {
            // force the task to run since we know that the queue has
            // something that needs to be sent
            IFS1bits.MI2C1IF = 1;
        }

    } else {
        *pflag = I2C1_MESSAGE_FAIL;
    }

}

void DRV_I2C1_MasterTRBInsert(
        uint8_t count,
        DRV_I2C1_TRANSACTION_REQUEST_BLOCK *ptrb_list,
        DRV_I2C1_MESSAGE_STATUS *pflag) {
    I2C1_MasterTRBInsert(count, (I2C1_TRANSACTION_REQUEST_BLOCK *) ptrb_list, (I2C1_MESSAGE_STATUS *) pflag);
}

void I2C1_MasterReadTRBBuild(
        I2C1_TRANSACTION_REQUEST_BLOCK *ptrb,
        uint8_t *pdata,
        uint8_t length,
        uint16_t address) {
    ptrb->address = address << 1;
    // make this a read
    ptrb->address |= 0x01;
    ptrb->length = length;
    ptrb->pbuffer = pdata;
}

void DRV_I2C1_MasterReadTRBBuild(
        DRV_I2C1_TRANSACTION_REQUEST_BLOCK *ptrb,
        uint8_t *pdata,
        uint8_t length,
        uint16_t address) {
    I2C1_MasterReadTRBBuild((I2C1_TRANSACTION_REQUEST_BLOCK *) ptrb, pdata, length, address);
}

void I2C1_MasterWriteTRBBuild(
        I2C1_TRANSACTION_REQUEST_BLOCK *ptrb,
        uint8_t *pdata,
        uint8_t length,
        uint16_t address) {
    ptrb->address = address << 1;
    ptrb->length = length;
    ptrb->pbuffer = pdata;
}

void DRV_I2C1_MasterWriteTRBBuild(
        DRV_I2C1_TRANSACTION_REQUEST_BLOCK *ptrb,
        uint8_t *pdata,
        uint8_t length,
        uint16_t address) {
    I2C1_MasterWriteTRBBuild((I2C1_TRANSACTION_REQUEST_BLOCK *) ptrb, pdata, length, address);
}

bool I2C1_MasterQueueIsEmpty(void) {
    return (i2c1_object.trStatus.s.empty);
}

bool DRV_I2C1_MasterQueueIsEmpty(void) {
    return I2C1_MasterQueueIsEmpty();
}

bool I2C1_MasterQueueIsFull(void) {
    return (i2c1_object.trStatus.s.full);
}

bool DRV_I2C1_MasterQueueIsFull(void) {
    return I2C1_MasterQueueIsFull();
}

#define MCHP24AA512_RETRY_MAX       100  // define the retry count
#define MCHP24AA512_ADDRESS         0x40 // slave device address
#define MCHP24AA512_DEVICE_TIMEOUT  50   // define slave timeout 

uint8_t MCHP24AA512_Read(
        uint16_t address,
        uint8_t *pData,
        uint16_t nCount) {
    I2C1_MESSAGE_STATUS status;
    uint8_t writeBuffer[3];
    uint16_t retryTimeOut, slaveTimeOut;
    uint16_t counter;
    uint8_t *pD;

    pD = pData;

    for (counter = 0; counter < nCount; counter++) {

        // build the write buffer first
        // starting address of the EEPROM memory
        writeBuffer[0] = (address >> 8); // high address
        writeBuffer[1] = (uint8_t) (address); // low low address

        // Now it is possible that the slave device will be slow.
        // As a work around on these slaves, the application can
        // retry sending the transaction
        retryTimeOut = 0;
        slaveTimeOut = 0;

        while (status != I2C1_MESSAGE_FAIL) {
            // write one byte to EEPROM (2 is the count of bytes to write)
            I2C1_MasterWrite(writeBuffer,
                    2,
                    MCHP24AA512_ADDRESS,
                    &status);

            // wait for the message to be sent or status has changed.
            while (status == I2C1_MESSAGE_PENDING) {
                // add some delay here

                // timeout checking
                // check for max retry and skip this byte
                if (slaveTimeOut == MCHP24AA512_DEVICE_TIMEOUT)
                    return (0);
                else
                    slaveTimeOut++;
            }

            if (status == I2C1_MESSAGE_COMPLETE)
                break;

            // if status is  I2C1_MESSAGE_ADDRESS_NO_ACK,
            //               or I2C1_DATA_NO_ACK,
            // The device may be busy and needs more time for the last
            // write so we can retry writing the data, this is why we
            // use a while loop here

            // check for max retry and skip this byte
            if (retryTimeOut == MCHP24AA512_RETRY_MAX)
                break;
            else
                retryTimeOut++;
        }

        if (status == I2C1_MESSAGE_COMPLETE) {

            // this portion will read the byte from the memory location.
            retryTimeOut = 0;
            slaveTimeOut = 0;

            while (status != I2C1_MESSAGE_FAIL) {
                // write one byte to EEPROM (2 is the count of bytes to write)
                I2C1_MasterRead(pD,
                        1,
                        MCHP24AA512_ADDRESS,
                        &status);

                // wait for the message to be sent or status has changed.
                while (status == I2C1_MESSAGE_PENDING) {
                    // add some delay here

                    // timeout checking
                    // check for max retry and skip this byte
                    if (slaveTimeOut == MCHP24AA512_DEVICE_TIMEOUT)
                        return (0);
                    else
                        slaveTimeOut++;
                }

                if (status == I2C1_MESSAGE_COMPLETE)
                    break;

                // if status is  I2C1_MESSAGE_ADDRESS_NO_ACK,
                //               or I2C1_DATA_NO_ACK,
                // The device may be busy and needs more time for the last
                // write so we can retry writing the data, this is why we
                // use a while loop here

                // check for max retry and skip this byte
                if (retryTimeOut == MCHP24AA512_RETRY_MAX)
                    break;
                else
                    retryTimeOut++;
            }
        }

        // exit if the last transaction failed
        if (status == I2C1_MESSAGE_FAIL) {
            return (0);
            break;
        }

        pD++;
        address++;

    }
    return (1);

}

void i2c_start(void) {
    int x = 0;
    I2C1CONbits.ACKDT = 0; //Reset any previous Ack
    __delay_us(10)

    I2C1CONbits.SEN = 1; //Initiate Start condition
    Nop();

    //the hardware will automatically clear Start Bit
    //wait for automatic clear before proceding
    while (I2C1CONbits.SEN) {
        __delay_us(1);
        x++;
        if (x > 20)
            break;
    }
    __delay_us(2);
}

void i2c_stop(void){
    int x = 0;
    I2C1CONbits.ACKDT = 0; //Reset any previous Ack
    __delay_us(10)

    I2C1CONbits.PEN = 1; // Stop Condition Enable bit
    Nop();

    //the hardware will automatically clear stop Bit
    //wait for automatic clear before proceding
    while (I2C1CONbits.PEN) {
        __delay_us(1);
        x++;
        UART1PutChar(x);
        if (x > 20)
            break;
    }
 //   I2C1CONbits.PEN = 0; // Stop Condition Enable bit
    __delay_us(2);
}

void i2c_repeatedStart(void){
        int x = 0;
    I2C1CONbits.ACKDT = 0; //Reset any previous Ack
    __delay_us(10)

    I2C1CONbits.RSEN = 1; //Initiate Start condition
    Nop();

    //the hardware will automatically clear Start Bit
    //wait for automatic clear before proceding
    while (I2C1CONbits.RSEN) {
        __delay_us(1);
        x++;
        if (x > 20)
            break;
    }
    __delay_us(2);
}
void i2c_restart(void)
{
   int x = 0;

   I2C1CONbits.RSEN = 1;	//Initiate restart condition
   Nop();
    
   //the hardware will automatically clear restart bit
   //wait for automatic clear before proceding
   while (I2C1CONbits.RSEN)
   {
    __delay_us(1);
      x++;
      if (x > 20)	break;
   }
    
   __delay_us(2);
}
//Resets the I2C bus to Idle
 void reset_i2c_bus(void)
{
   int x = 0;

   //initiate stop bit
   I2C1CONbits.PEN = 1;

   //wait for hardware clear of stop bit
   while (I2C1CONbits.PEN)
   {
     __delay_us(2);
      x ++;
      if (x > 20) break;
   }
   I2C1CONbits.RCEN = 0;
   IFS1bits.MI2C1IF = 0; // Clear Interrupt
   I2C1STATbits.IWCOL = 0;
   I2C1STATbits.BCL = 0;
  __delay_us(10);
}

//basic I2C byte send
char send_i2c_byte(int data)
{
   int i;

   while (I2C1STATbits.TBF) { }
   IFS1bits.MI2C1IF = 0; // Clear Interrupt
   I2C1TRN = data; // load the outgoing data byte

   // wait for transmission
   for (i=0; i<500; i++)
   {
      if (!I2C1STATbits.TRSTAT) break;
      __delay_us(1);

      }
      if (i == 500) {
      return(1);
   }

   // Check for NO_ACK from slave, abort if not found
   if (I2C1STATbits.ACKSTAT ==1)
   {
      UART1PutStr("no ack-reset");
      reset_i2c_bus();
      return(1);
   }
   
  __delay_us(2);
   return(0);
}


//function reads data, returns the read data, no ack
char i2c_read(void)
{
   int i = 0;
   char data = 0;

   //set I2C module to receive
   I2C1CONbits.RCEN = 1;

   //if no response, break
   while (!I2C1STATbits.RBF)
   {
      i ++;
      if (i > 2000) break;
   }

   //get data from I2CRCV register
   data = I2C1RCV;

   //return data
   return data;
}

//function reads data, returns the read data, with ack
char i2c_read_ack(void)	//does not reset bus!!!
{
   int i = 0;
   char data = 0;
  
   //set I2C module to receive
   I2C1CONbits.RCEN = 1;

   //if no response, break
   while (!I2C1STATbits.RBF)
   {
      i++;
      if (i > 2000) break;
     // UART1PutChar('R');
   }
   i=0;
   //get data from I2CRCV register
   data = I2C1RCV;
  
   __delay_us(2);  
   
   //i2c_ack();
   __delay_us(2);

   return data;
   
}
void i2c_mIdleI2C1(void){
    
while((I2C1CON&0x001F)!=0){UART1PutChar('d');}
//Wait for Acken, Rcen, Pen, Rsen and Sen to clear


}
void i2c_ack(void){
     I2C1CONbits.ACKDT=0 ;
             Nop();
             //I2C1CONbits.ACKEN=0;
             I2C1CONbits.RCEN=0;
             I2C1CONbits.PEN=0;
             I2C1CONbits.RSEN=0;
             I2C1CONbits.SEN=0;
      //__delay_us(1);       
       I2C1CONbits.ACKEN = 1;
   while (I2C1CONbits.ACKEN==1){UART1PutChar('A');};
}

void i2c_nack(void){
     I2C1CONbits.ACKDT=1 ;
             Nop();
             //I2C1CONbits.ACKEN=0;
             I2C1CONbits.RCEN=0;
             I2C1CONbits.PEN=0;
             I2C1CONbits.RSEN=0;
             I2C1CONbits.SEN=0;
      //__delay_us(1);       
       I2C1CONbits.ACKEN = 1;
   while (I2C1CONbits.ACKEN==1){UART1PutChar('N');};
}
void si7020test(){
    //i2c_start();  
    
    
    send_i2c_byte(0x81);
    
    send_i2c_byte(0xE3);
    
   // char cc=i2c_read_ack();
    
 
    
    
}
int calculateTemperature(uint16_v code)
{
   
   
   uint16_t temp;
    // Calculate the temperature using the formula from the datasheet
    
    //temp = ((((int)17572 * code.w) + 0x8000) >> 16) - 4685;
    //temp= temp/100;
   
    temp=175.72* code.w /65536-46.85 ;
    // Return value is to be scaled by 10
    //*tempCx10 = (temp + 5) / 10;
    tempo =temp;
    return temp;
}
 int calculateHumidity(uint16_v humcode)
{
   uint32_t hum;
   hum= humcode.w;
    // Calculate the temperature using the formula from the datasheet
    hum=125* hum /65536-6 ;
    return hum;
}