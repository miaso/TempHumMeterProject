#include "xc.h"
#define FCY     16000000ULL //TO DO
#include "i2c1.h"
#include "uart1.h"

#include <libpic30.h>
#include "extralDefines.h"






// For Manual: Needs Details
// When PIC clock increase past 1MHz, will need to update these delays
#define Delay_Bus_Free_Time		{ __delay_us(2) }		// minimum 1.3us
#define Delay_Start_Hold_Time	{ __delay_us(1) }				// minimum 600 nano sec
#define Delay_SCL				{ __delay_us(2) }				// maximum 400kHz period, thus 2.5us / 2
#define Delay_Stop_Hold_Time	{ __delay_us(1) }				// minimum 50ns
//--------------------------------------------------------------


unsigned TempBit0,I2C_DataByteH,I2C_DataByteL ;



void INITIALIZE_SI7020(void){
    I2C_SCL_TRS = 0;
    I2C_SDA_TRS = 0;
}

// For Manual: Needs Details
void I2C_StopBit(void)
{
	I2C_SCL_L;
	I2C_SDA_L;
	Delay_SCL;
	I2C_SCL_HF;
	I2C_SDA_L;
	Delay_Stop_Hold_Time;
	I2C_SCL_HF;
	I2C_SDA_HF;
}

//--------------------------------------------------------------
// For Manual: Needs Details
void I2C_StartBit(void)
{
    
	I2C_SCL_HF;
	I2C_SDA_HF;
	Delay_Bus_Free_Time;
	I2C_SCL_HF;
	I2C_SDA_L;
	Delay_Start_Hold_Time;
	I2C_SCL_L;
	I2C_SDA_HF; // Release Data Line
}

#define Si7020Address	0x40
#define SlaveRead		0x01
#define SlaveWrite		0x00

unsigned char TempUChar01,TempUChar02;
//--------------------------------------------------------------
// For Manual: Needs Details
//void I2C_ReadByte( unsigned char Read0Write1, unsigned char NACKorACK)
unsigned char I2C_SlaveAddressAnd( unsigned char Mode)
{

	
}

#define SlaveACK	0
#define SlaveNACK	1
//--------------------------------------------------------------
// For Manual: Needs Details
unsigned char SlaveReponse(void)
{
	Delay_SCL;
	I2C_SCL_HF;
	Delay_SCL;
	while (I2C_SCL_State == 0); // Slave Clock Stretching
	TempBit0 = I2C_SDA_State;
	I2C_SCL_L;
	if (TempBit0)
		return (1);
	else
		return (0);
}

//--------------------------------------------------------------
// For Manual: Needs Details
void I2C_SendByte(unsigned char ByteToSend)
{
	TempUChar01 = 0;
	while (TempUChar01<8)
	{
		if (ByteToSend&0b10000000)
			{ I2C_SDA_HF; }
		else
			{ I2C_SDA_L; }
		ByteToSend <<= 1;
		Delay_SCL;
		I2C_SCL_HF;
		Delay_SCL;
		I2C_SCL_L;
		TempUChar01++;
	}
	I2C_SDA_HF; // Release Data Line
}

#define MasterACK	0
#define MasterNACK	1
//--------------------------------------------------------------
// For Manual: Needs Details
unsigned char I2C_GetByte(unsigned char MasterResponse)
{
	I2C_SDA_HF; // Release Data Line
	TempUChar01 = 0;
	while (TempUChar01<8)
	{
		Delay_SCL;
		I2C_SCL_HF;
		Delay_SCL;
		if (I2C_SDA_State==1)
			TempUChar02 |= 0b00000001;
		else
			TempUChar02 &= 0b11111110;
		TempUChar02 <<= 1;
		I2C_SCL_L;
		TempUChar01++;
	}
	Delay_SCL;
	if (MasterResponse == MasterACK)
		{ I2C_SDA_L; }	// Send Acknowledge
	else
		{ I2C_SDA_HF; } // Send NACK
	I2C_SCL_HF;
	Delay_SCL;
	I2C_SCL_L;
	I2C_SDA_HF;
	return (TempUChar02);
}

#define Si7020_NoDeviceFound	0xFF
#define Si7020_MeasureCmdNACK	0xFE
#define Si7020_CmdNoHoldRH		0xF5
#define Si7020_Good				0x01
//--------------------------------------------------------------
// For Manual: Needs Details
unsigned char Si7020_ReadRH_Start(void)
{
	I2C_StartBit();
	I2C_SlaveAddressAnd(SlaveWrite);
	if (SlaveReponse() == SlaveNACK)
		return (Si7020_NoDeviceFound);
	I2C_SendByte(Si7020_CmdNoHoldRH);
	if (SlaveReponse() == SlaveNACK)
		return (Si7020_MeasureCmdNACK);
	I2C_StartBit(); //Restart
	return (Si7020_Good);
}

#define Si7020_Data_Complete	1
#define Si7020_Data_Not_Ready	0
//--------------------------------------------------------------
// For Manual: Needs Details
unsigned char Si7020_ReadRH_Again(void)
{
	I2C_SlaveAddressAnd(SlaveRead);
	if (SlaveReponse() == SlaveNACK)
		return (Si7020_Data_Not_Ready);
	I2C_DataByteH = I2C_GetByte(MasterACK);
	I2C_DataByteL = I2C_GetByte(MasterNACK);
	// to do: need to capture checksum; just for customer?
/*	TempUChar01 = I2C_GetByte();*/
	return (Si7020_Data_Complete);
}

//--------------------------------------------------------------
void Si7020_ReadRH(void)
{
	if (Si7020_ReadRH_Start() != Si7020_Good){
        UART1PutStr("sigood");
		return;
    }
	while( Si7020_ReadRH_Again() != Si7020_Data_Complete)
	{
        UART1PutStr("while");
		ClrWdt();
	}
	I2C_StopBit();
	return;
}

////==============================================================
