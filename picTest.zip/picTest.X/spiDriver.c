#include "extralDefines.h"
#include "spiDriver.h"
/******************************************************************************/
// global variables
/******************************************************************************/


/******************************************************************************/
// local variables
/******************************************************************************/
volatile uint16_t eepromIndex;

uint16_t writeAddressCheck;

uint16_t bytesToWrite0;
uint16_t bytesToWrite1;

/******************************************************************************/
// transfer one byte over SPI
/******************************************************************************/
uint8_t spiTransferByte(uint8_t data)
{
    uint8_t receivedByte;

    while(SPI1_TX_BUFFER_FULL);
    SPI1_INTERRUPT_CLEAR;
    SPI1_FAULT_CLEAR;
    SPI1_OVERFLOW_CLEAR;
    SPI1BUF = data; 
    while(!SPI1_RX_BUFFER_FULL);
    receivedByte = SPI1BUF;

    return receivedByte;
}
/******************************************************************************/
// transfer one byte over SPI2
/******************************************************************************/
uint8_t spi2TransferByte(uint8_t data)
{
    uint8_t receivedByte;

    while(SPI2_TX_BUFFER_FULL);
    SPI2_INTERRUPT_CLEAR;
    SPI2_FAULT_CLEAR;
    SPI2_OVERFLOW_CLEAR;
    SPI2BUF = data; 
    while(!SPI2_RX_BUFFER_FULL);
    receivedByte = SPI2BUF;

    return receivedByte;
}
