#include "xc.h"

#define SI7020ADR = 0x40
#define MEASURE_HUM_HOLD_CMD =0xF5
#define MEASURE_HUM_NOHOLD_CMD = 0xE3
#define MEASURE_TEMP_HOLD_CMD = 0xE3
#define MEASURE_TEMP_NOHOLD_CMD = 0xF3
#define READ_LAST_TEMP_CMD = 0xE0
#define RESETSI7020 = 0XFE
#define WRITE_RHT_USERREG_CMD = 0xE6
#define READ_RHT_USERREG_CMD = 0xE7
#define WRITE_HEATERCONTROLREGISTER_CMD = 0x51
#define READ_HEATERCONTROLREGISTER_CMD = 0x11
 

 

 void INITIALIZE_SI7020(void);
void I2C_StopBit(void);
void I2C_StartBit(void);
unsigned char I2C_SlaveAddressAnd( unsigned char Mode);
unsigned char SlaveReponse(void);
void I2C_SendByte(unsigned char ByteToSend);
unsigned char I2C_GetByte(unsigned char MasterResponse);
unsigned char Si7020_ReadRH_Start(void);
unsigned char Si7020_ReadRH_Again(void);
void Si7020_ReadRH(void);

 
